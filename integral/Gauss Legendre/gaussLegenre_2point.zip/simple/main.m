clear
close all
clc

syms x f(x)

ff = "x^2";
f(x) = str2sym(ff);
a = -2;
b = 4;
s = gaussLegendre_2p(f, a, b);

fprintf("integral of %s from %.2f to %.2f = %.4f\n", ff, a, b, s)
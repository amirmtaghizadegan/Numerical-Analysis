function result = gaussLegendre_2p(f, a, b)
syms g(t) t
%% changing variable x to t
 % x = (b-a)*t/2+(b+a)/2
 g(t) = f((b-a)*t/2+(b+a)/2)*(b-a)/2; %g is f(t)dt
%% using gauss legendre formula
aa = -1/sqrt(3);
result = double(g(-aa)+ g(aa));
end